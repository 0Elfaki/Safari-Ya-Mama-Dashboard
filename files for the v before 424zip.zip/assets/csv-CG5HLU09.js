import{c as s}from"./index-PWNdpOym.js";/**
 * @license lucide-react v1.68.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a={name:"download",size:24,node:[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]]};a.node;const l=s(a),r=t=>{const n=t==null?"":String(t),e=/^[=+\-@]/.test(n)?`'${n}`:n;return/[",\n]/.test(e)?`"${e.replace(/"/g,'""')}"`:e};function i(t,n){const e=Array.from(new Set(t.flatMap(o=>Object.keys(o))));return[e.join(","),...t.map(o=>e.map(c=>r(o[c])).join(","))].join(`
`)}function m(t,n){const e=document.createElement("a");e.href=URL.createObjectURL(new Blob([n],{type:"text/csv;charset=utf-8"})),e.download=t,e.click(),setTimeout(()=>URL.revokeObjectURL(e.href),1e3)}export{l as D,m as d,i as t};
