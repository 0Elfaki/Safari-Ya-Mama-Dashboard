import{c as t}from"./index-PWNdpOym.js";/**
 * @license lucide-react v1.68.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e={name:"calendar-x",size:24,node:[["path",{d:"M8 2v3",key:"1ioesn"}],["path",{d:"M16 2v3",key:"otl347"}],["rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",key:"h1oib"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"m14 13-4 4",key:"1gib57"}],["path",{d:"m10 13 4 4",key:"153uiq"}]]};e.node;const d=t(e);export{d as C};
